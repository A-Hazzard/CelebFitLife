type ChatMessage = {
    id: string;
    userName: string;
    content: string;
}

export type {ChatMessage}