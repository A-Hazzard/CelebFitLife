import { db } from '@/config/firebase';
import {
  collection,
  addDoc,
  query,
  orderBy,
  onSnapshot,
  serverTimestamp,
} from 'firebase/firestore';

export async function sendChatMessage(slug: string, userName: string, content: string) {
  const ref = collection(db, 'streams', slug, 'messages');
  await addDoc(ref, {
    userName,
    content,
    createdAt: serverTimestamp(),
  });
}

export function listenToMessages(slug: string, cb: (msgs: any[]) => void) {
  const ref = collection(db, 'streams', slug, 'messages');
  const q = query(ref, orderBy('createdAt', 'asc'));
  return onSnapshot(q, (snap) => {
    const messages = snap.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }));
    cb(messages);
  });
}
