import { LocalVideoTrack, RemoteVideoTrack, LocalAudioTrack, RemoteAudioTrack } from 'twilio-video';

export function attachVideoTrack(track: LocalVideoTrack | RemoteVideoTrack, container: HTMLDivElement) {
  const el = track.attach(); // returns <video> or <audio>
  container.appendChild(el);
}

export function stopAndDetachTrack(track: any) {
  if (track.kind === 'video') {
    const videoTrack = track as LocalVideoTrack | RemoteVideoTrack;
    if ('stop' in videoTrack) {
      videoTrack.stop();
    }
    videoTrack.detach().forEach((el) => el.remove());
  } else if (track.kind === 'audio') {
    const audioTrack = track as LocalAudioTrack | RemoteAudioTrack;
    if ('stop' in audioTrack) {
      audioTrack.stop();
    }
  }
}
